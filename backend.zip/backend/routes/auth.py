from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from models.models import User, Guest
from schemas.schemas import OTPRequest, OTPVerify
from utils.security import create_access_token
from utils.otp import generate_otp, store_otp, verify_otp

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/request-otp")
def request_otp(data: OTPRequest, db: Session = Depends(get_db)):
    phone_clean = data.phone.strip().replace("+91", "")

    user = db.query(User).filter(User.phone == phone_clean).first()
    guest = db.query(Guest).filter(Guest.phone == phone_clean).first()

    if not user and not guest:
        raise HTTPException(status_code=404, detail="Phone not registered")

    otp = generate_otp()
    store_otp(phone_clean, otp)

    print("OTP:", otp)  # REMOVE in production

    return {"message": "OTP sent successfully"}


@router.post("/verify-otp")
def verify_user_otp(data: OTPVerify, db: Session = Depends(get_db)):
    phone_clean = data.phone.strip().replace("+91", "")

    if not verify_otp(phone_clean, data.otp):
        raise HTTPException(status_code=400, detail="Invalid or expired OTP")

    user = db.query(User).filter(User.phone == phone_clean).first()
    if user:
        token = create_access_token({
            "sub": str(user.id),
            "role": "organizer"
        })
        return {"access_token": token, "role": "organizer"}

    guest = db.query(Guest).filter(Guest.phone == phone_clean).first()
    if guest:
        token = create_access_token({
            "sub": str(guest.id),
            "role": "guest",
            "event_id": guest.event_id
        })
        return {"access_token": token, "role": "guest"}

    raise HTTPException(status_code=404, detail="User not found")